# Strand-seq pipeline

Run with this command:

```
snakemake -j 10 --cluster-config Snake.cluster.json --cluster "{cluster.sbatch} -p {cluster.partition} --cpus-per-task {cluster.n} --time {cluster.time} --mem {cluster.mem}" --timestamp --keep-going --latency-wait 60 --restart-times 1
```

## Goal

The pipeline is tailored towards human, **paired-end** Strand-seq data (multiple cells, 
single sample). It will accomplish the following:

 * map reads against correct GRCh38 reference genome
 * include the correct *RG* tags
 * count reads in different resolutions
 * plot whole-cell and per-chromosome overviews

## Setup

In order to run this pipeline you will need to undertake three steps:

 1. Checkout this code
    ```
    git clone git@git.embl.de:meiers/strand-seq-pipeline.git
    ```
 
 2. Copy (or link) the `fastq` files for each single cell into a subdirectory
    `fastq/`, e.g. like this:
    ```
    cd strand-seq-pipeline
    mkdir fastq
    cd fastq
    ln -s /path/to/where/reads/are/stored/reads_1_sequence.txt.gz
    ln -s /path/to/where/reads/are/stored/reads_2_sequence.txt.gz
    ```
    
    >   **Note** Files should end with `_1_sequence.txt.gz`. You can even
    >   rename them during the linking/copying.
    
    Of course *filename expansions* (such as `*`) come in very handy at
    this step. The file names will determine the cell names in MosaiCatcher,
    so take a look at the *Note on file names* below.
    
    >   **Note** I recommend running the whole pipeline from `/scratch`, in 
    >   which case it is better to **copy** files

 3. Edit `Snakefile` to specify a **sample name**. This will be used for
    file names but also as read group within the BAM files. 

    If neccesary
    also edit `Snake.config.json` (e.g. different reference genome or
    file paths have changed) and `Snake.cluster.json` (e.g. when experiencing
    cluster issues).

Afterwards you can run the pipeline on the EMBL cluster using the command
line shown at the top. If run from scratch (and fastq files have been copied)
you can set `-j 500` in the command line - this will enable the highest possible
parallelism.

## Note on file names

By default the cell name is the name of the fastq file without preceding path
and without `_?_sequence.txt.gz`. However, if the fastq file names are very long
you might with to abbreviate them. 

For that reason there is a switch in `Snakefile` called *abbreviate_names*. When
set to True it will remove common prefixes and suffixes of fastq names. 

## Debugging

With time things will definitley change, so this pipeline will have to 
be adapted. In that case a basic knowledge of *Snakemake* is required.

In case of cluster problems you should edit `Snake.cluster.json` to increase
memory or time limits. This can be done for single rules (as I did for `map_reads`).
To run it without the cluster just specify `snakemake -j 5`.

